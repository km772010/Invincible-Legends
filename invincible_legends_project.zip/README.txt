
Invincible Legends - Unity Project
----------------------------------
1. Open this project in Unity 2022.3 LTS (or later)
2. Go to File > Build Settings
3. Switch platform to Android
4. Click "Build" to generate the APK

Includes:
- Swipe and tap controls
- Card battle system
- Anime-style Invincible characters
- Placeholder arena and sound effects

Need Help?
Ask ChatGPT to guide you through Unity Cloud Build or GitHub CI.

Enjoy!
